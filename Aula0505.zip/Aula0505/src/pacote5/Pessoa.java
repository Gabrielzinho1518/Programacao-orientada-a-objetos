package pacote5;

public class Pessoa {
	public void dizerOla() {
		Pessoa p = new Pessoa();
		System.out.println("Olá!");
	}
	
	public void dizerOla(String nome) {
		System.out.println("Olá, "+nome+"!");
	}
}
