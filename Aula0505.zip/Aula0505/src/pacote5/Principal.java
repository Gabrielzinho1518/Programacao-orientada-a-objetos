package pacote5;

import java.util.Scanner;

public class Principal {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		Pessoa p = new Pessoa();
		p.dizerOla();
		p.dizerOla("Gabriel");
		

	}

}
