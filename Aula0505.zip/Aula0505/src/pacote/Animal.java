package pacote;

public class Animal {
	public void fazerSom() {
		System.out.println("O Animal esta fazendo um som");
	}

}
