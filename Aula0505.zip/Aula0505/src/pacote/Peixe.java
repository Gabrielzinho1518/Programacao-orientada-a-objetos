package pacote;

public class Peixe extends Animal{
	public void fazerSom() {
	System.out.println("Glub glub");
	}
}
