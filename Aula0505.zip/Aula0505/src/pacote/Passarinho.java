package pacote;

public class Passarinho extends Animal{
	public void fazerSom() {
		System.out.println("Bem-te-vi");
	}
}
