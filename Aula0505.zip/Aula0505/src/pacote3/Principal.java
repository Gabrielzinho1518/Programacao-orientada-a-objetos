package pacote3;

public class Principal {

    public static void main(String[] args) {

        Calculadora c = new Calculadora();

        int resultado = c.somar(4, 3);
        System.out.println("Soma: " + resultado);

        resultado = c.somar(resultado, resultado);
        System.out.println("Soma: " + resultado);

        int resultado2 = c.somar2(4, 7, 9);
        System.out.println("Soma 2: " + resultado2);

        int resultado3 = c.somar3(5, 5, 8);
        System.out.println("Soma 3: " + resultado3);
        
        resultado2 = c.multiplicar(4, 7);
    }
}