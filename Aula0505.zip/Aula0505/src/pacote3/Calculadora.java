package pacote3;

public class Calculadora {

    public int somar(int x, int y) {
        return x + y;
    }

    public int somar2(int x, int y, int z) {
        return x + y + z;
    }

    public int somar3(int x, int y, int z) {
        return x + y + z;
    }
    
    public int multiplicar(int x, int y) {
    	return x * y;
    }
    
    public double multiplicar(double x, double y) {
    	return x * y;
    }
}