package pacote2;

public class Pessoa {
	public void trabalhar() {
		System.out.println("Pessoa:");
		System.out.println("Trabalhando");
	}

}
