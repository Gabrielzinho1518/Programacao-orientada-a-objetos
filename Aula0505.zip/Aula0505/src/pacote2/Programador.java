package pacote2;

public class Programador extends Pessoa{
	public void trabalhar() {
		System.out.println("Pessoa:");
		System.out.println("Programando...");
	}
	

}
