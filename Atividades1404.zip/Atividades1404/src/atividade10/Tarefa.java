package atividade10;

public class Tarefa {
	String descricao;
	boolean concluida;
	

}
