package atividade8;

import java.util.Scanner;

public class Main {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        // Usuário fixo no sistema
        Usuario u = new Usuario("adm", "1234");

        System.out.println("Digite o nome de usuário:");
        String usuarioDigitado = sc.nextLine();

        System.out.println("Digite a senha:");
        String senhaDigitada = sc.nextLine();

        u.login(usuarioDigitado, senhaDigitada);

        u.exibirStatus();

        System.out.println("\nDeseja fazer logout? (s/n)");
        char opcao = sc.next().charAt(0);

        if (opcao == 's' || opcao == 'S') {
            u.logout();
        }

        u.exibirStatus();

        sc.close();
    }
}