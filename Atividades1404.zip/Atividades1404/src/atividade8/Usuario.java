package atividade8;

public class Usuario {
    String nomeUsuario;
    String senha;
    boolean logado = false;

    public Usuario(String nomeUsuario, String senha) {
        this.nomeUsuario = nomeUsuario;
        this.senha = senha;
    }

    public void login(String usuario, String senha) {
        if (logado = logado) {
            logado = true;
            System.out.println("Login realizado com sucesso!");
        } else {
            logado = false;
            System.out.println("Usuário ou senha incorretos!");
        }
    }

    public void logout() {
        logado = false;
        System.out.println("Logout realizado.");
    }

    public void exibirStatus() {
        System.out.println("Status do usuário:");
        if (logado) {
            System.out.println("Usuário está logado.");
        } else {
            System.out.println("Usuário NÃO está logado.");
        }
    }
}