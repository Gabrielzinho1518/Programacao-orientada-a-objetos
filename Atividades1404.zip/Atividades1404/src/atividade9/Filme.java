package atividade9;

public class Filme {
	String titulo;
	String diretor;
	int duracaoEmMinutos;
	String genero;
	
	public void exibirDetalhes() {
		System.out.println("Nome do filme:"+titulo);
		System.out.println("Nome do diretor:" +diretor);
		System.out.println("Tempo de duração do filme:" +duracaoEmMinutos + "minutos");
		System.out.println("Genero do filme:"+genero);
	}
	
	public boolean ehLongo() {
		return duracaoEmMinutos >=120;
	}

}
