package atividade9;

import java.util.Scanner;

public class Main {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		Filme f = new Filme ();
		
		System.out.println("Qual o nome do filme?");
		f.titulo = sc.nextLine();
		System.out.println("Qual é o nome do diretor?");
		f.diretor = sc.nextLine();
		System.out.println("Quantos minutos tem a duração do filme?");
		f.duracaoEmMinutos = sc.nextInt();
		System.out.println("Qual o genero do filme?");
		f.genero = sc.nextLine();
		
		
		f.exibirDetalhes();
	}
	

}
