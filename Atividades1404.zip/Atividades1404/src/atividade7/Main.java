package atividade7;

import java.util.Scanner;

public class Main {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        Produto p1 = new Produto();

        System.out.println("Digite o nome do produto:");
        p1.nome = sc.nextLine();

        System.out.println("Digite o preço:");
        p1.preco = sc.nextDouble();

        System.out.println("Digite a quantidade:");
        p1.quantidade = sc.nextInt();

        //  Produto 2 (valores fixos)
        Produto p2 = new Produto("Notebook", 3500.0, 5);

        //  Exibindo informações
        System.out.println("\n=== Produto 1 ===");
        p1.exibirInformacoes();
        System.out.println("Valor total: " + p1.calcularValorTotal());

        System.out.println("\n=== Produto 2 ===");
        p2.exibirInformacoes();
        System.out.println("Valor total: " + p2.calcularValorTotal());

        sc.close();
    }
}