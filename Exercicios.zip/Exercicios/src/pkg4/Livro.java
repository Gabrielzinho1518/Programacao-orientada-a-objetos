//4 - Crie uma classe Livro com os atributos título, autor e ano de publicação. Imprima as informações do livro na tela.

package pkg4;

public class Livro {
	
	public static void main(String[] args) {
		String titulo = "Harry Potter e as reliquias da morte parte I";
		String autor = "J. K. Rowling";
		float anoPublicacao = 1998;
		
		System.out.println("Titulo do livro:"+titulo);
		System.out.println("Autor(a) do livro:"+autor);
		System.out.println("Ano de fabricação do livro:"+anoPublicacao);

	
	}
}