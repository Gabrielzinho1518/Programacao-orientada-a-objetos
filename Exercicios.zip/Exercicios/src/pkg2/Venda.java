package pkg2;

import java.util.Scanner;

public class Venda {

	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		Computador c = new Computador();
		
		System.out.println("Digite a marca do computador:");
		c.marca = scanner.nextLine();
		System.out.println("Digite o modelo do computador:");
		c.modelo = scanner.nextLine();
		System.out.println("Digite o tipo do computador:");
		c.tipo = scanner.nextLine();
		System.out.println("Digite o preço do computador:");
		c.preco = scanner.nextFloat();
		
		Computador c2 = new Computador();
		c2.marca = "Dell";
		c2.modelo = "Intel i5";
		c2.tipo = "Computador";
		c2.preco = 3000;
		
		System.out.println("\nComputador 1:");
        System.out.println(c.marca + " " + c.modelo + " " + c.tipo + " " + c.preco);

        System.out.println("\nComputador 2:");
        System.out.println(c2.marca + " " + c2.modelo + " " + c2.tipo + " " + c2.preco);

        scanner.close();
	}

}
