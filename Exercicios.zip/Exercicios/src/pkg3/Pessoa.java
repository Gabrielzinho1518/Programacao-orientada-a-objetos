//3 - Crie uma classe Pessoa com os atributos nome, idade e gênero. Imprima as informações da pessoa na tela.
package pkg3;

public class Pessoa {

	public static void main(String[] args) {
		String nome = "Gabriel";
		int idade = 22;
		String genero = "masculino";
		
		System.out.println("Nome da pessoa:"+nome);
		System.out.println("Idade pessoa:"+idade);
		System.out.println("Genero da pessoa:"+genero);
		
	}
}
