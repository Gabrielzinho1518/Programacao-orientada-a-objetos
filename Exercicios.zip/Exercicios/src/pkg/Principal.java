package pkg;

import java.util.Scanner;

public class Principal {

	public static void main(String[] args) {
		Scanner scanner = new Scanner (System.in);
		Carro c = new Carro();
		scanner.nextLine();
		System.out.println("Digite a marca do carro:");
		c.marca = scanner.nextLine();
		System.out.println("Digite o modelo do carro:");
		c.modelo = scanner.nextLine();
		System.out.println("Digite o ano de fabricação do carro:");
		c.anoFabricacao = scanner.nextInt();

		Carro c2 = new Carro();
		System.out.println("Digite a marca do segundo carro:");
		c2.marca = scanner.nextLine();
		System.out.println("Digite o modelo do carro:");
		c2.modelo = scanner.nextLine();
		System.out.println("Digite o ano de fabricação do carro:");
		c2.anoFabricacao = scanner.nextInt();
	
	}
}
