//1- Faça um programa para leitura de dois números e após faça as quatro operações matemáticas (Soma, Subtração, Multiplicação e divisão)
package pacote;

import java.util.Scanner;

public class Exerc1 {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		
		System.out.println("Digite um número inteiro:\n");
		int n1 = sc.nextInt();
		System.out.println("Digite um segundo número inteiro:\n");
		int n2 = sc.nextInt();
		
		int soma = n1 + n2;
		int sub = n1 - n2;
		int mult = n1 * n2;
		int div = n1 / n2;
		
		System.out.println("\n---Resultados:---");
		System.out.println("Soma:\n" +soma);
		System.out.println("sub:\n" +sub);
		System.out.println("mult:\n" +mult);
		System.out.println("div:\n" +div);
		
		sc.close();

	}

}
