//3-Escrever um algoritmo para ler quatro valores float, calcular a sua média, e escrever na tela os que são superiores à média.
package pacote;

import java.util.Scanner;

public class Exerc3 {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		
		System.out.println("Digite um numero:");
		float n1 = sc.nextFloat();
		System.out.println("Digite o segundo numero:");
		float n2 = sc.nextFloat();
		System.out.println("Digite o terceiro numero");
		float n3 = sc.nextFloat();
		System.out.println("Digite o quarto numero");
		float n4 = sc.nextFloat();
		
		float media = n1 + n2 + n3 + n4 / 4;
		System.out.println("A média dos valores é:\n" +media);
		
	
		
		sc.close();
	
		
	}
}
