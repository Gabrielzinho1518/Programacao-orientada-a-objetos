/*
 Crie uma classe chamada Retangulo com os atributos largura e altura. Crie um construtor que inicialize esses atributos.
 Implemente os métodos calcularArea(), que retorna a área do retângulo, calcularPerimetro(), que retorna o perímetro, calcularDiagonal(), 
 que calcula e retorna a diagonal utilizando a função Math.sqrt(), e
 ehQuadrado(), que retorna true caso a largura seja igual à altura.
 */
package atividade4;

public class Principal {
    public static void main(String[] args) {

        // Criando um retângulo com largura e altura fixas
        Retangulo retangulo = new Retangulo(10, 10);
        
        System.out.println("Largura: " + retangulo.largura);
        System.out.println("Altura: " + retangulo.altura);
        System.out.println("Área: " + retangulo.calcularArea());
        System.out.println("Perímetro: " + retangulo.calcularPerimetro());
        System.out.println("Diagonal: " + retangulo.calcularDiagonal());

        if (retangulo.ehQuadrado()) {
            System.out.println("O retângulo é um quadrado.");
        } else {
            System.out.println("O retângulo não é um quadrado.");
        }
    }
}