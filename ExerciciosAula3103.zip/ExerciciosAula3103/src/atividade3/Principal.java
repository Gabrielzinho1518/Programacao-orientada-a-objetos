/*
 3 - Crie uma classe chamada Aluno com os atributos nome, nota1, nota2 e nota3. 
 Crie um construtor que inicialize esses atributos. Implemente os métodos calcularMedia(), que retorna a média das três notas, aprovado(), 
 que retorna true se a média for maior ou igual a 7, maiorNota(), 
 que retorna a maior nota entre as três, e menorNota(), que retorna a menor nota entre elas.
 */

package atividade3;

public class Principal {
    public static void main(String[] args) {
    	
        Aluno aluno = new Aluno("Gabriel", 2, 10, 8);

        // Exibindo informações do aluno
        System.out.println("Nome do aluno: " + aluno.nome);
        System.out.println("Notas: " + aluno.nota1 + ", " + aluno.nota2 + ", " + aluno.nota3);
        
        if (aluno.aprovado()) {
            System.out.println("Situação: Aprovado");
        } else {
            System.out.println("Situação: Reprovado");
        }

        System.out.println("Maior nota: " + aluno.maiorNota());
        System.out.println("Menor nota: " + aluno.menorNota());
    }
}