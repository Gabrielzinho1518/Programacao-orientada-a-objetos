/*
 - Crie uma classe chamada ContaBancaria com os atributos titular e saldo. 
 Crie um construtor que inicialize esses atributos. 
 Implemente os métodos depositar(double valor), que adiciona um valor ao saldo, sacar(double valor), 
 que realiza o saque apenas se houver saldo suficiente e retorna true ou false, transferir(double valor, ContaBancaria destino), 
 que transfere um valor para outra conta caso haja saldo suficiente, e consultarSaldo(), que retorna o saldo atual da conta
*/

package atividade2;

import java.util.Scanner;

public class Main {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        System.out.println("Digite o nome do titular:");
        String titular = sc.nextLine();

        System.out.println("Digite o saldo da conta:");
        float saldo = sc.nextFloat();

        ContaBancaria conta1 = new ContaBancaria(titular, saldo);

        sc.nextLine();
        System.out.println("Digite o nome do segundo titular:");
        String titular2 = sc.nextLine();

        System.out.println("Digite o saldo da segunda conta:");
        float saldo2 = sc.nextFloat();

        ContaBancaria conta2 = new ContaBancaria(titular2, saldo2);

        System.out.println("\nSaldo inicial conta 1: " + conta1.consultarSaldo());

        System.out.println("Digite o valor para depósito:");
        double deposito = sc.nextDouble();
        conta1.depositar(deposito);
        System.out.println("Saldo após depósito: " + conta1.consultarSaldo());

    
        System.out.println("Digite o valor para saque:");
        double saque = sc.nextDouble();
        if (conta1.sacar(saque)) {
            System.out.println("Saque realizado!");
        } else {
            System.out.println("Saldo insuficiente!");
        }
        System.out.println("Saldo após saque: " + conta1.consultarSaldo());

  
        System.out.println("Digite o valor para transferir:");
        double transferencia = sc.nextDouble();
        if (conta1.transferir(transferencia, conta2)) {
            System.out.println("Transferência realizada!");
        } else {
            System.out.println("Saldo insuficiente para transferir!");
        }


        System.out.println("\nSaldo final conta 1: " + conta1.consultarSaldo());
        System.out.println("Saldo final conta 2: " + conta2.consultarSaldo());

        sc.close();
    }
}