/*
 - Crie uma classe chamada ContaBancaria com os atributos titular e saldo. 
 Crie um construtor que inicialize esses atributos. 
 Implemente os métodos depositar(double valor), que adiciona um valor ao saldo, sacar(double valor), 
 que realiza o saque apenas se houver saldo suficiente e retorna true ou false, transferir(double valor, ContaBancaria destino), 
 que transfere um valor para outra conta caso haja saldo suficiente, e consultarSaldo(), que retorna o saldo atual da conta
*/
package atividade2;

public class ContaBancaria {
	String titular;
	float saldo;
	
	public ContaBancaria(String titular, float saldo) {
		this.titular = titular;
		this.saldo = saldo;
	}
	public double depositar(double valor) {
		return valor++;
	}
	 public boolean sacar(double valor) {
	        if (this.saldo >= valor) {
	            this.saldo -= valor;
	            return true;
	        } else {
	            return false;
	        }
	 }
	 public boolean transferir(double valor, ContaBancaria destino) {
	        if (this.sacar(valor)) {
	            destino.depositar(valor);
	            return true;
	        } else {
	            return false;
	        }
	    }
	    public float consultarSaldo() {
	        return saldo;
	    }
	}