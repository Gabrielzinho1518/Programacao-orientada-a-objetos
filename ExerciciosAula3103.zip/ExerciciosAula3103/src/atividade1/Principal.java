package atividade1;

import java.util.Scanner;

public class Principal {

	    public static void main(String[] args) {
	        Scanner sc = new Scanner(System.in);

	        System.out.print("Digite o nome do produto: ");
	        String nome = sc.nextLine();

	        System.out.print("Digite o preço: ");
	        float preco = sc.nextFloat();

	        System.out.print("Digite a quantidade inicial: ");
	        int quantidade = sc.nextInt();

	        Produto produto = new Produto(nome, preco, quantidade);

	        System.out.println("Valor total em estoque: " + produto.calcularValorTotalEstoque());

	        // Verificar estoque
	        if (produto.temEstoque()) {
	            System.out.println("Produto disponível em estoque.");
	        } else {
	            System.out.println("Produto sem estoque.");
	        }

	        // Adicionar estoque
	        System.out.print("Quantidade para adicionar ao estoque: ");
	        int add = sc.nextInt();
	        produto.adicionarEstoque(add);

	        System.out.println("Novo valor total em estoque: " + produto.calcularValorTotalEstoque());

	        // Vender produto
	        System.out.print("Quantidade para vender: ");
	        int venda = sc.nextInt();

	        if (produto.vender(venda)) {
	            System.out.println("Venda realizada com sucesso!");
	        } else {
	            System.out.println("Estoque insuficiente!");
	        }

	        System.out.println("Quantidade final em estoque: " + produto.quantidade);

	        sc.close();
	    }
	}