package Exerc5;

import java.util.ArrayList;
import java.util.List;

public class Principal {

    public static Conta maiorSaldo(List<Conta> contas) {

        Conta maior = contas.get(0);

        for (Conta c : contas) {

            if (c.getSaldo() > maior.getSaldo()) {
                maior = c;
            }
        }

        return maior;
    }

    public static void main(String[] args) {
        List<Conta> contas = new ArrayList<>();
        contas.add(new Conta(101, "Gabriel", 500.00));
        contas.add(new Conta(102, "Maria", 3500.50));
        contas.add(new Conta(103, "Carlinhos", 5000.75));
        contas.add(new Conta(104, "Jeff Hardy", 5300.00));

        Conta contaMaiorSaldo = maiorSaldo(contas);
        
        System.out.println("Conta com maior saldo:");
        contaMaiorSaldo.exibirDados();
    }
}