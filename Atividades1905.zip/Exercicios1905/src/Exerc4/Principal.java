package Exerc4;

import java.util.ArrayList;
import java.util.List;

public class Principal {

    public static void main(String[] args) {
        List<Livro> livros = new ArrayList<>();

        livros.add(new Livro("A Revolução dos Bichos", "George Orwell", 1945));
        livros.add(new Livro("O Hobbit", "J.R.R. Tolkien", 1937));
        livros.add(new Livro("Capitães da Areia", "Jorge Amado", 1937));
        livros.add(new Livro("Percy Jackson", "Rick Riordan", 2005));

        for (int i = 0; i < livros.size(); i++) {

            for (int j = i + 1; j < livros.size(); j++) {

                if (livros.get(i).getAno() > livros.get(j).getAno()) {

                    Livro temp = livros.get(i);
                    livros.set(i, livros.get(j));
                    livros.set(j, temp);
                }
            }
        }
        for (Livro l : livros) {
            l.exibirDados();
        }
    }
}