package Exerc3;

import java.util.ArrayList;
import java.util.List;

public class Principal {

    public static int contarMulheres(List<Pessoa> pessoas) {

        int quantidade = 0;

        for (Pessoa p : pessoas) {

            if (p.getSexo().equalsIgnoreCase("Feminino")) {
                quantidade++;
            }
        }

        return quantidade;
    }

    public static void main(String[] args) {

        List<Pessoa> pessoas = new ArrayList<>();

        // Adicionando pessoas na lista
        pessoas.add(new Pessoa("Aninha", 30, "Feminino"));
        pessoas.add(new Pessoa("Pedro", 32, "Masculino"));
        pessoas.add(new Pessoa("Carla", 20, "Feminino"));
        pessoas.add(new Pessoa("John", 28, "Masculino"));

        int totalMulheres = contarMulheres(pessoas);

        System.out.println("Quantidade de mulheres: " + totalMulheres);
    }
}