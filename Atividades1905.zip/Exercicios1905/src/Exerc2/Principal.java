package Exerc2;

import java.util.ArrayList;
import java.util.List;

public class Principal {

    public static void main(String[] args) {

        List<Aluno> alunos = new ArrayList<>();

        alunos.add(new Aluno("Gabriel", 9.5, 10.0));
        alunos.add(new Aluno("Aninha", 6.0, 9.5));
        alunos.add(new Aluno("Pedrão", 0.0, 5.0));

        for (Aluno a : alunos) {
            a.verificarSituacao();
        }
    }
}