package pacote;

import java.util.ArrayList;
import java.util.List;

public class Principal{

    public static void main(String[] args) {

        List<Produto> produtos = new ArrayList<>();

        produtos.add(new Produto("PC gamer", 6500.00, 3));
        produtos.add(new Produto("Mouse Razer", 200, 10));
        produtos.add(new Produto("Teclado Razer", 250.00, 7));

        for (Produto p : produtos) {
            p.exibirDados();
        }
    }
}