package pacote1;

import java.util.ArrayList;
import java.util.List;

//Crie uma classe Produto com atributos nome, preco e quantidade.
//Crie uma lista de produtos e adicione alguns produtos nessa lista. Em seguida, percorra a lista e imprima os dados de cada produto.

public class Principal {

	public static void main(String[] args) {
		List<Produto> listaProdutos = new ArrayList<Produto>();
		
		Produto produto1 = new Produto("Caneta azul", 950, 1);
		Produto produto2 = new Produto("Mouse Gamer", 20, 100);
		Produto protudo3 = new Produto("Monitor", 400, 20);
		
		listaProdutos.add(produto1);
		listaProdutos.add(produto2);
		listaProdutos.add(protudo3);
		
		exibirProdutos(listaProdutos);
		
		}
	public static void exibirProdutos(List<Produto> lista) {
		for (Produto p : lista) {
		    System.out.println("Nome: " + p.nome);
		    System.out.println("Preço: " + p.preco);
		    System.out.println("Quantidade: " + p.quantidade);
		}
	}
}
